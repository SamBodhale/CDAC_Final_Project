package com.example.dafodils_gateentry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.example.dafodils_gateentry")
public class DafodilsGateEntryApplication {

	public static void main(String[] args) {
		SpringApplication.run(DafodilsGateEntryApplication.class, args);
	}

}
