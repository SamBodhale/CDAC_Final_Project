package com.example.dafodils_gateentry.service;

import com.example.dafodils_gateentry.model.VisitorRequest;
import com.example.dafodils_gateentry.model.Watchman;
import com.example.dafodils_gateentry.repository.VisitorRequestRepository;
import com.example.dafodils_gateentry.repository.WatchmanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class WatchmanService {

    @Autowired
    private WatchmanRepository watchmanRepository;

    @Autowired
    private VisitorRequestRepository visitorRequestRepository;

    // Register a new watchman
    public void registerWatchman(Watchman watchman) {
        watchmanRepository.save(watchman);
    }

    // Find a watchman by email
    public Optional<Watchman> findByEmail(String email) {
        return watchmanRepository.findByEmail(email);
    }

    // Validate the password for a Watchman
    public boolean validatePassword(Watchman watchman, String password) {
        return watchman.getPassword().equals(password);
    }

    // Get a watchman by ID
    public Watchman getWatchmanById(Long watchmanId) {
        return watchmanRepository.findById(watchmanId).orElse(null);
    }

    // Get visitor requests by room number (Assuming all are pending until processed)
    public List<VisitorRequest> getVisitorRequestsByRoomNumber(String roomNumber) {
        return visitorRequestRepository.findByRoomNumber(roomNumber);
    }
}
