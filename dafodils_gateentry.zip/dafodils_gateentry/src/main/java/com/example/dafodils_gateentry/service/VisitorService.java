package com.example.dafodils_gateentry.service;

import com.example.dafodils_gateentry.model.Visitor;
import com.example.dafodils_gateentry.repository.VisitorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class VisitorService {

    @Autowired
    private VisitorRepository visitorRepository;
    
    // Save or update a visitor
    public Visitor save(Visitor visitor) {
        return visitorRepository.save(visitor);
    }

    // Find a visitor by email
    public Optional<Visitor> findByEmail(String email) {
        return visitorRepository.findByEmail(email);
    }

    // Register a new visitor without encoding the password
    public void registerVisitor(Visitor visitor) {
        // Directly save the visitor without encoding the password
        save(visitor);
    }

    // Authenticate a visitor by email and password without password matching
    public boolean authenticateVisitor(String email, String password) {
        Optional<Visitor> visitorOptional = visitorRepository.findByEmail(email);
        if (visitorOptional.isPresent()) {
            Visitor visitor = visitorOptional.get();
            // Directly compare the provided password with the stored password
            return password.equals(visitor.getPassword());
        }
        return false;
    }

    // Get a visitor by ID
    public Visitor getVisitorById(Long visitorId) {
        return visitorRepository.findById(visitorId).orElse(null);
    }
}
