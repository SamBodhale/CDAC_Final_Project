package com.example.dafodils_gateentry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DafodilsGateEntryApplicationTests {

	@Test
	void contextLoads() {
	}

}
